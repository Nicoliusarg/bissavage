window.BIS_FEED = {
  "meta": { "season": "TWW S3 (demo)", "updated": "local" },
  "labels": { "Warrior": { "label": "Guerrero", "specs": { "Fury": "Furia" } } },
  "data": { "Warrior": { "Fury": [ { "slot": "twoHand", "id": 19019, "source": { "type": "raid", "instance": "Ejemplo", "boss": "Jefe A" } } ] } }
};